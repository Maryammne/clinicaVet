package models;

public enum Perfil {
	
	OPERADOR, VETERINARIO

}
