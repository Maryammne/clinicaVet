package Job;

import models.Operador;
import models.Perfil;
import models.Tutor;
import models.Veterinario;
import play.jobs.Job;
import play.jobs.OnApplicationStart;

@OnApplicationStart
public class Inicializador extends Job {

	@Override
	public void doJob() {

		if (Tutor.count() == 0) {

			Tutor joao = new Tutor();
			joao.nome = "João da Silva";
			joao.cpf = "12345678909";
			joao.save();

			Tutor Maria = new Tutor();
			Maria.nome = "Maria da Silva";
			Maria.cpf = "98765432107";
			Maria.save();
		}

		if (Veterinario.count() == 0) {

			Veterinario Marina = new Veterinario();
			Marina.nome = "Marina Ellen Ida";
			Marina.crm = "32165497";
			Marina.login = "MarinaEllen";
			Marina.senha = "0105";
			Marina.perfil = Perfil.VETERINARIO;
			Marina.save();

			Veterinario Emanuel = new Veterinario();
			Emanuel.nome = "Aroldo Emanuel";
			Emanuel.crm = "98765432107";
			Emanuel.login = "Emanuel";
			Emanuel.senha = "1212";
			Emanuel.perfil = Perfil.VETERINARIO;
			Emanuel.save();
		}
		
		if(Operador.count() == 0) {
			
			Operador Anitta = new Operador();
			Anitta.email = "AnittaLouyse@gmail.com";
			Anitta.login = "AnittaLouyse";
			Anitta.senha = "0708";
			Anitta.perfil = Perfil.OPERADOR;
			Anitta.save();
			
			Operador Ramon = new Operador();
			Ramon.email = "Ramon@gmail.com";
			Ramon.login = "RamonSantos";
			Ramon.senha = "1111";
			Ramon.perfil = Perfil.OPERADOR;
			Ramon.save();
			
		}
	}

}
